//
//  AppDelegate.h
//  PortingIos8
//
//  Created by anxs on 15/5/14.
//  Copyright (c) 2015年 tbago. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

