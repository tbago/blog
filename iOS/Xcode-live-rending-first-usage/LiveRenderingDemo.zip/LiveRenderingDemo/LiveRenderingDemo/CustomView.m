//
//  CustomView.m
//  LiveRenderingDemo
//
//  Created by anxs on 15/5/12.
//  Copyright (c) 2015年 tbago. All rights reserved.
//

#import "CustomView.h"

@implementation CustomView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
