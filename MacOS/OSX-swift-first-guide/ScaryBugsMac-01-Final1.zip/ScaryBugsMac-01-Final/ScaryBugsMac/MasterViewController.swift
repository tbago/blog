/*
* Copyright (c) 2015 Razeware LLC
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*/

import Cocoa

class MasterViewController: NSViewController {
  var bugs = [ScaryBugDoc]()

  override func viewDidLoad() {
    super.viewDidLoad()
    // Do view setup here.
  }

  func setupSampleBugs() {
    let bug1 = ScaryBugDoc(title: "Potato Bug", rating: 4.0,
      thumbImage:NSImage(named: "potatoBugThumb"), fullImage: NSImage(named: "potatoBug"))
    let bug2 = ScaryBugDoc(title: "House Centipede", rating: 3.0,
      thumbImage:NSImage(named: "centipedeThumb"), fullImage: NSImage(named: "centipede"))
    let bug3 = ScaryBugDoc(title: "Wolf Spider", rating: 5.0,
      thumbImage:NSImage(named: "wolfSpiderThumb"), fullImage: NSImage(named: "wolfSpider"))
    let bug4 = ScaryBugDoc(title: "Lady Bug", rating: 1.0,
      thumbImage:NSImage(named: "ladybugThumb"), fullImage: NSImage(named: "ladybug"))

    bugs = [bug1, bug2, bug3, bug4]
  }
}

// MARK: - NSTableViewDataSource
extension MasterViewController: NSTableViewDataSource {
  func numberOfRowsInTableView(aTableView: NSTableView) -> Int {
    return self.bugs.count
  }

  func tableView(tableView: NSTableView, viewForTableColumn tableColumn: NSTableColumn?, row: Int) -> NSView? {
    // 1
    var cellView: NSTableCellView = tableView.makeViewWithIdentifier(tableColumn!.identifier, owner: self) as! NSTableCellView

    // 2
    if tableColumn!.identifier == "BugColumn" {
      // 3
      let bugDoc = self.bugs[row]
      cellView.imageView!.image = bugDoc.thumbImage
      cellView.textField!.stringValue = bugDoc.data.title
      return cellView
    }

    return cellView
  }
}

// MARK: - NSTableViewDelegate
extension MasterViewController: NSTableViewDelegate {
}
